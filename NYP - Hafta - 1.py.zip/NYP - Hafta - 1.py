# In[1]:
type(25.6)

# In[3]:
type("alperen")

# In[4]:
type(25)

# In[5]:
a = "alperen"

# In[6]:
a

# In[7]:
type(a)

# In[8]:
b = 10

# In[9]:
type(b)

# In[10]:
c = 24.5

# In[11]:
type(c)

# In[13]:
c = "5"

# In[14]:
type(c)

# In[16]:
list = [2, "alperen", 2.3]

# In[17]:
list

# In[19]:
print(list)

# In[21]:
print("Sayilar ve Stringler : ", list)

# In[22]:
ders = "Nesne Tabanli Programlama"

# In[23]:
print(ders[1])

# In[24]:
print(ders[-1])

# In[25]:
print(ders[4 : 9]) #4 - 9 arasi karakterleri gostermesi icin.

# In[26]:
print(ders[4 :]) #4. karakterden en sonuncu karaktere kadar gostermesi icin.

# In[27]:
print(ders[4 : 12 : 3]) #4. karakterden 12. karaktere 3'er 3'er atlayarak git.

# In[28]:
len(ders) #uzunlugunu ogrenmek icin "len" fonksiyonu kullanilir.

# In[29]:
a = 25

# In[30]:
float(a) # a degiskenini "float" veri tipine donusturmek icin

# In[31]:
type(a)

# In[32]:
int(a)# a degiskenini "int" veri tipine donusturmek icin

# In[33]:
type(a)

# In[34]:
str(a) # a degiskenini "str" veri tipine donusturmek icin

# In[35]:
print(a)

# In[36]:
type(a)

# In[40]:
print("Alperen\nErtuna")

# In[41]:
print(12,10,2010,sep = "\n") # "sep" aralara koyulacak karakteri belirler.

# In[43]:
print(12,10,2010,sep = "/")

# In[46]:
a = 3
b = 4
print("{} + {} 'un toplami {} 'dir".format(a,b,a+b))

# In[47]:
print(a,b,a+b)

# In[48]:
"{1} {0} {2}".format(43, "Alperen", 54)

# In[49]:
list = [3, 4, 5, 6, 8 , 9]
list

# In[50]:
list[1] = 10
list

# In[51]:
list.append(14) #listenin sonuna eleman ekler.
list

# In[52]:
list.pop() #son eklenen veriyi cikarir.

# In[57]:
list = [1, 5 , 8, 14 ,9 ]
list.sort()
list

# In[59]:
list = [1, 5 , 8, 14 ,9 ]
list.sort(reverse = True)
list

# In[62]:
list = ["Ceren", "Sevval", "Alperen", "Alp"]
list.sort()
list

# In[63]:
list = ["Ceren", "Sevval", "Alperen", "Alp"]
list.sort(reverse = True)
list

# In[64]:
list0 = [1, 2, 3]
list1 = [4, 5, 6]
list2 = [7, 8, 9]

newList = [list0, list1, list2]
newList

# In[65]:
newList[1][0]

# In[66]:
tuple = ("Alperen",2,3,4,5.6,6,7,8,9)
tuple

# In[71]:
tuple = ("Alperen",2,3,4,5.6,6,7,8,9)
tuple.index("Alperen")

# In[72]:
tuple = ("Alperen",2,3,4,5.6,6,7,8,9)
tuple.index(3)

# In[80]:
tuple = ("elma", "armut", "ayva")
tuple[0] = "cerne" #tuple degistirilemez ve silinemez.

# In[83]:
sozluk1 = {"sifir":0, "bir":1, "iki":2, "uc":3}
sozluk1